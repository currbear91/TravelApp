free for personal use.
for commercial use a commercial license is avaible for $40.00usd. payable only via paypal(keisadiya@yahoo.com)

email pinkard@gmail.com for any questions.
Http://comicfontsby.tehandeh.com